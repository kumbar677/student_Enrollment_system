from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from models import db, User, StudentDetails
from werkzeug.security import check_password_hash
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Login successful!', 'success')
            if user.role == 'admin':
                return redirect(url_for('admin.dashboard'))
            return redirect(url_for('student.dashboard'))
        else:
            flash('Login failed. Check your email and password.', 'danger')
            
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('auth.register'))

        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'warning')
            return redirect(url_for('auth.register'))

        # Create new user
        new_user = User(name=name, email=email, role='student')
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.flush() # Flush to get ID for student details

        # Create student details linked to user with auto-generated enrollment number
        # Format: UNIV + Year + 3-digit-user-id
        from datetime import datetime
        current_year = datetime.now().year
        enroll_no = f"UNIV{current_year}{new_user.id:03d}"
        
        student_details = StudentDetails(user_id=new_user.id, enrollment_no=enroll_no)
        db.session.add(student_details)
        
        db.session.commit()
        
        flash('Account created! You can now login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user:
            from flask import current_app
            from flask_mail import Message
            from itsdangerous import URLSafeTimedSerializer
            
            s = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            token = s.dumps(user.email, salt='password-reset-salt')
            
            # Create the reset link
            # Use PUBLIC_URL if available (from run_public.py) to ensure link works on other devices
            public_url = current_app.config.get('PUBLIC_URL')
            if public_url:
                reset_path = url_for('auth.reset_password', token=token, _external=False)
                reset_link = f"{public_url}{reset_path}"
            else:
                reset_link = url_for('auth.reset_password', token=token, _external=True)
            
            # Send email
            msg = Message('Password Reset Request',
                          sender=current_app.config['MAIL_USERNAME'],
                          recipients=[user.email])
            msg.body = f'''To reset your password, visit the following link:
{reset_link}

If you did not make this request then simply ignore this email and no changes will be made.
'''
            mail = current_app.extensions['mail']
            try:
                mail.send(msg)
                flash('An email has been sent with instructions to reset your password.', 'info')
            except Exception as e:
                flash(f'Error sending email: {e}', 'danger')
                
        else:
             # Even if email doesn't exist, show same message for security, or explicit one if preferred.
             # User asked for "click that password reset link will goto there email"
             # I'll be helpful and say if email not found for now as it's a student app.
             flash('Email address not found.', 'danger')
             
        return redirect(url_for('auth.login'))
        
    return render_template('auth/forgot_password.html')

@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for('student.dashboard'))
        
    from flask import current_app
    from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
    
    s = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
    
    try:
        email = s.loads(token, salt='password-reset-salt', max_age=3600) # 1 hour expiration
    except SignatureExpired:
        flash('The password reset link has expired.', 'warning')
        return redirect(url_for('auth.forgot_password'))
    except BadSignature:
        flash('Invalid or expired token.', 'warning')
        return redirect(url_for('auth.forgot_password'))
        
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('auth.reset_password', token=token))
            
        user = User.query.filter_by(email=email).first_or_404()
        user.set_password(password)
        db.session.commit()
        
        flash('Your password has been updated! You are now able to log in', 'success')
        return redirect(url_for('auth.login'))
        
    return render_template('auth/reset_password.html')
