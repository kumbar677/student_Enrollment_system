from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import base64

try:
    import qrcode
except ImportError:
    qrcode = None

def generate_upi_qr(upi_id, name, amount, transaction_note="Enrollment Fee"):
    """
    Generates a UPI QR code and returns as base64 string.
    UPI URL Format: upi://pay?pa=<upi_id>&pn=<name>&am=<amount>&tn=<note>
    """
    # Ensure amount is string with 2 decimals
    amount_str = "{:.2f}".format(float(amount))
    
    # Construct UPI URL
    # standardized UPI deep link format
    upi_url = f"upi://pay?pa={upi_id}&pn={name}&am={amount_str}&tn={transaction_note}&cu=INR"
    
    # Try local generation
    if qrcode:
        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(upi_url)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()
            return f"data:image/png;base64,{img_str}", upi_url
        except Exception as e:
            print(f"Local QR generation failed: {e}")
            pass
            
    # Fallback to Online API (Robust fix)
    import urllib.parse
    encoded_url = urllib.parse.quote(upi_url)
    api_url = f"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data={encoded_url}"
    return api_url, upi_url

def generate_pdf_report(data, title="Report"):
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, height - 50, title)
    
    p.setFont("Helvetica", 12)
    y = height - 80
    
    for line in data:
        p.drawString(100, y, line)
        y -= 20
        if y < 50:
            p.showPage()
            y = height - 50
            
    p.showPage()
    p.save()
    
    buffer.seek(0)
    return buffer

from flask_mail import Message
from flask import current_app

def send_email_with_attachment(to_email, subject, body, attachment_path=None, attachment_name='document.pdf'):
    """
    Sends an email using Flask-Mail.
    """
    try:
        msg = Message(subject, recipients=[to_email])
        msg.body = body
        msg.sender = current_app.config.get('MAIL_USERNAME')
        
        if attachment_path:
            with current_app.open_resource(attachment_path) as fp:
                msg.attach(attachment_name, "application/pdf", fp.read())
        
        mail = current_app.extensions.get('mail')
        if mail:
            mail.send(msg)
            print(f"Email sent to {to_email}")
            return True
        else:
            print("Mail extension not found.")
            return False
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False
